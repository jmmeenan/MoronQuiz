//
//  Level3ArrowViewController.swift
//  Think Fast
//
//  Created by Logan Young on 9/22/22.
//

import Foundation
import UIKit

class Level3ArrowViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}
