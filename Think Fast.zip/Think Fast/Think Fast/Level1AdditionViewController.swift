//
//  Level1AdditionViewController.swift
//  Think Fast
//
//  Created by Logan Young on 9/22/22.
//

import Foundation
import UIKit

class Level1AdditionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}
